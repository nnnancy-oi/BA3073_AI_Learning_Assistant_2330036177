# BA3073 deployment progress

Verified 2 November 2026. Interim record: Task 3 remains incomplete.

## Local deployment

- Docker Desktop 29.8.2 on an arm64 Mac. Project `yyh-ai-learning-assistant`, image `yyh-ai-learning-assistant:local`, `compose.local.yml`, bound to `127.0.0.1:14242`.
- Healthy container, health JSON status ok, UI HTTP 200 and actual Safari login page rendered. `local-ui-check.txt` generated locally at 17:32:38 +0800, PASS. A current local Safari screenshot with address bar is now saved outside source as local-browser.jpg.
- Full dependency build timed out at the Docker Hub authorization endpoint. Successful `Dockerfile.cached` fallback reused an existing application runtime and overlaid current sources/static assets. This is not a successful clean dependency download. On a clean machine use the original Dockerfile with working registry/package access.
- Frontend: 12 tests passed with Node.js. Separately, backend: 117 tests passed in 7.52s in an isolated temporary container with mocked providers.
- Revised `backend/pipelines/essay_html.py` requests BA3073 structure, <=20 A4 pages, factual screenshots/evidence, completed/failed/pending distinctions and no invented results, URLs or secrets. Source/local/ECS SHA256 matches `aaaaa483f136d78cc178028bfd07bb00a13f6d63fd3d18d8b5b6909ff8c55cc9`.

Restart with Docker Desktop running:

```bash
docker compose -p yyh-ai-learning-assistant -f compose.local.yml up -d --no-build
bash scripts/check-local-ui.sh
```

## ACR transfer and ECS deployment completed

- Private Hangzhou personal ACR: `crpi-qworj2939ff08rp2.cn-hangzhou.personal.cr.aliyuncs.com/yyh-ba3073-2026/ai-learning-assistant`.
- Locally built `yyh-ai-learning-assistant:ecs-amd64-acr`, linux/amd64, using current source and an existing matching runtime. Uploaded tag `ba3073-20261102-amd64-v1`; push log PASS.
- Locally pushed and ECS-pulled repository digest: `sha256:a93dc14f240116d4a95f6577689cf62d4560fbdd6147b05273f2a45324e4f266`.
- ECS `120.26.28.223`, Hangzhou, Ubuntu 22.04 x86_64, 2 vCPU / 2 GiB. Project `/root/ba3073/AI_Learning_Assistant`.
- Existing Compose project `ai-learning-assistant` preserved. Image-only `compose.acr.override.yml` pins the above digest over existing `compose.yml`; data/workspace mounts and environment preserved.
- Container `92a08e22a1cf`, `ai-learning-assistant-backend-1`, healthy at about 19:44 +0800. Loopback health/UI succeed. Account and encrypted personal-key resolution still work after recreation.
- `scripts/deploy-acr-on-ecs.sh` pulled before stopping the old service, backed up data/workspace consistently while stopped and retained the prior image/configuration for rollback. Private backup `/root/ba3073/yyh-pre-acr.mXRGfM` includes the database, its separate master-key file and artifacts. No restore test performed.
- Workbench suffered repeated WebSocket/input failures. Completed deployment used native SSH with host identity independently verified against the authenticated console, strict host-key checking retained, and no server credential change. Registry login was temporary; passwords were not written to source/logs.

### Network evidence

Task 2 publishes port 14242 on all host interfaces. With explicit user confirmation, the stale TCP 14242 source rule was replaced by the current Mac/SSH peer IPv4 `/32`. A fresh Mac request to `http://120.26.28.223:14242/ui/` returned HTTP 200.

The ECS-origin request to its own public IP still timed out (HTTP 000, curl exit 28). Loopback checks succeed. These are different request origins/paths; no NAT/firewall root cause is established. Both the original and fresh failed self-check are preserved, rather than relabelled PASS. Supplied cloud JPEGs are earlier address-bar captures of login/essay interfaces, not fresh evidence of this ACR image or HTTPS.

## Live report generation completed

The deployed service's ordinary `core.create_run` was invoked over authenticated SSH under the existing student account and personal model profile. No application auth/session changes were made. This was a service-core invocation, not an interactive browser submission.

- Run `43c63132-df0c-4e5a-838b-d2ea8a180550`, status succeeded, created 2026-11-02T12:07:29Z (20:07:29 China time).
- Provider/model `openai_compatible` / `qwen3.6-flash`; provider stage 66.252s; total 69.145s.
- Original generated HTML, PDF and manifest downloaded and retained. This proves one real model call, artifact persistence and PDF conversion, not future availability or the whole browser interaction path.
- Submission draft was fact-checked, formatted and supplemented with the actual historical screenshots after generation. Six A4 pages, rendered and visually checked. It remains interim until missing requirements are fulfilled.

## Still required

1. Local screenshot with address bar is now complete; retained with submission evidence.
2. Owned/authorized domain or subdomain, DNS and applicable mainland ICP filing/access prerequisites.
3. Actual Nginx, valid public TLS certificate and independent proxy access gate. Verify rejected access without the independent identity and HTTPS browser success with it; save address-bar evidence.
4. After the proxy works, bind backend to localhost and remove the public 14242 rule. This has not been done yet.
5. Public GitHub repository and complete current-source archive are supplied; the user explicitly approved public visibility.
6. Finalize the <=20-page report with Task 3 URL and actual screenshots.

`compose.ecs.yml` and `docs/deployment/` are final-proxy preparation. Nginx mTLS template passed isolated syntax validation with synthetic certificates for example.invalid only. No real domain, Nginx, public TLS or browser client identity has been deployed.

## Final evidence update

Current Chrome ECS login capture with full public-IP address/port saved as cloud-browser.jpg outside source. Source IPv4 /32 was updated again after the client network changed, following explicit confirmation. The ECS address was added to the system proxy exception list with consent, preserving previous exceptions. The repository is now public at https://github.com/nnnancy-oi/BA3073_AI_Learning_Assistant_2330036177. The report remains interim because Task 3 is incomplete.


## Latest verified update — 2026-11-02T22:37:06+08:00

official cloudflared 2026.10.7 checksum-verified and installed; Nginx configured at 127.0.0.1:18080; both services active. Temporary endpoint: https://style-mixing-van-advancement.trycloudflare.com/ui/
Anonymous request: HTTP 302 to email authentication, TLS certificate verification result 0. The student completed the email PIN, but JavaScript/CSS redirected to authentication and failed CORS checks. Full application UI and persistent authorized admission are NOT verified. Backend direct-IP access remains restricted to the authorized /32; it has not been closed because the replacement path is unverified.

No student-controlled DNS A record to ECS or Certbot certificate on ECS. No domain purchased. Temporary provider hostnames are not equivalent to the specified architecture and may stop/change. Do not describe this as a completed Task 3. See docs/deployment/QUICK_TUNNEL.md.

