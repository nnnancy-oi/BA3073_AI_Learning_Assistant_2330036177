# HTTPS deployment preparation

Current status (2 November 2026): private ACR push, digest-pinned ECS pull and
healthy direct-IP deployment completed. See `../ASSIGNMENT_PROGRESS.md`. Domain,
HTTPS and independent proxy access control below remain preparation. These
general commands are not a transcript of the completed deployment.

The Nginx template passed an isolated local `nginx -t` syntax check using temporary
synthetic certificates and `example.invalid`; it has not been validated on ECS
or with a real domain/client identity.

These are reviewed preparation files and commands, **not evidence of completed
domain setup, HTTPS, or reverse-proxy authentication**. No command
in this document has been applied to the ECS server as part of preparing it.
Run each stage only after its prerequisites are satisfied; do not paste the
whole document into a terminal.

The separate access-control layer in this preparation is **mutual TLS (mTLS)**:
Nginx requires an authorized browser client certificate before serving the app.
The app still uses its existing bearer-token login. This avoids the shared
`Authorization` header conflict that a plain HTTP Basic Auth gate would create.
No certificate authority, browser identity, or server certificate was generated
or installed while preparing these files. No identity-provider account is needed.

## 1. Domain and registry prerequisites

The existing ECS is in Hangzhou at `120.26.28.223`. A domain that points to a
China mainland server and provides a public website requires ICP filing.
Borrowing a subdomain or acquiring a certificate alone does not establish that
the domain/server combination is ready for public access. Resolve that
requirement with the domain owner and Aliyun before enabling the public site.
See [Aliyun's filing FAQ](https://help.aliyun.com/zh/icp-filing/basic-icp-service/support/for-the-record-process-faq).

Prepare a controlled domain/subdomain, its DNS A record, a valid certificate for
that exact hostname with its matching private key, and an ACR repository. Use
the registry hostname and login username shown in **your** ACR console; new and
older personal instances use different hostname formats. Do not substitute an
invented registry hostname. The login, tagging, push, and pull workflow follows
[Aliyun's ACR guide](https://help.aliyun.com/zh/acr/user-guide/use-a-container-registry-personal-edition-instance-to-push-and-pull-images/).

Keep registry passwords, server/client TLS private keys, client identity bundles, application
database, and model secrets outside the source submission. Enter passwords
interactively; do not put them in command arguments, reports, or screenshots.

## 2. Build the ECS image locally, then push to ACR

Run from the source project folder **on the student's computer**. The existing
`yyh-ai-learning-assistant:local` is a local Mac image; retagging an arm64 image
does not convert it to amd64. Build a separate amd64 image from `Dockerfile`,
then verify its reported platform. Docker Desktop can emulate this target;
the dependency build can be slow and needs working registry/package downloads.
See [Docker's platform-build documentation](https://docs.docker.com/build/building/multi-platform/).

```bash
docker buildx build --platform linux/amd64 --load \
  -f Dockerfile -t yyh-ai-learning-assistant:ecs-amd64 .
docker image inspect yyh-ai-learning-assistant:ecs-amd64 \
  --format '{{.Os}}/{{.Architecture}}'
```

Proceed only if the build succeeds and the result is `linux/amd64`.
`Dockerfile.cached` requires a base with the matching target architecture.
The current prepared image `yyh-ai-learning-assistant:ecs-amd64` was built
with `--platform linux/amd64 --build-arg BASE_IMAGE=ai-learning-assistant-backend:ecs-amd64`
using the cached Dockerfile; its inspected platform is `linux/amd64`. This is
a documented cached-runtime fallback, not a successful clean dependency build.
The arm64 `:local` base must not be substituted for an ECS build. If frontend source was changed, rebuild its
`backend/static/` output before image construction.

Test the new image locally before upload, using a spare localhost port to avoid
interrupting the existing port-14242 container:

```bash
docker run -d --rm --name yyh-amd64-check --platform linux/amd64 \
  -p 127.0.0.1:14244:14242 yyh-ai-learning-assistant:ecs-amd64
# Wait for startup, then repeat these if startup is still in progress.
curl -fsS http://127.0.0.1:14244/health
curl -fsS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:14244/ui/
# After confirming the test: stop only this disposable test container.
docker stop yyh-amd64-check
```

Replace every `YOUR_...` value below with the existing ACR details. Choose a
unique tag and use the same full `AILA_IMAGE` value on the Mac and ECS.

```bash
export AILA_REGISTRY='YOUR_ACR_HOST'
export AILA_ACR_USER='YOUR_ACR_USERNAME'
export AILA_IMAGE='YOUR_ACR_HOST/YOUR_NAMESPACE/yyh-ai-learning-assistant:YOUR_TAG'
docker login --username "$AILA_ACR_USER" "$AILA_REGISTRY"
docker tag yyh-ai-learning-assistant:ecs-amd64 "$AILA_IMAGE"
docker push "$AILA_IMAGE"
docker image inspect "$AILA_IMAGE" --format '{{json .RepoDigests}}'
```

Record the real push result and digest. Do not claim a completed push because
tagging succeeded or because an ACR repository exists.

## 3. Pull and deploy the same image on ECS

Run **on ECS** from `/root/ba3073/AI_Learning_Assistant`. Transfer the reviewed
source changes, including `compose.ecs.yml`, to that directory first. Back up
the database and encryption master key together, plus `workspace/`, to a
private location before changing the current container. Pause writes while
making a consistent SQLite backup; a live plain-file copy is not sufficient.
Keep the backup outside Git and the submission archive.

```bash
cd /root/ba3073/AI_Learning_Assistant
export AILA_REGISTRY='YOUR_ACR_HOST'
export AILA_ACR_USER='YOUR_ACR_USERNAME'
export AILA_IMAGE='YOUR_ACR_HOST/YOUR_NAMESPACE/yyh-ai-learning-assistant:YOUR_TAG'
docker login --username "$AILA_ACR_USER" "$AILA_REGISTRY"
docker pull "$AILA_IMAGE"
docker image inspect "$AILA_IMAGE" \
  --format '{{.Os}}/{{.Architecture}} {{json .RepoDigests}}'
```

Require `linux/amd64` and compare the repository digest with the Mac push.
Use a digest-pinned `AILA_IMAGE` after confirming it if you need an immutable
deployment. The Compose project remains `ai-learning-assistant`, retaining the
existing host data/workspace directories.

For Task 2's direct-IP evidence, first restrict inbound TCP 14242 in the security
group to the student's own current public IPv4 `/32`. Only then use the temporary
direct binding:

```bash
export AILA_BIND_IP=0.0.0.0
docker compose -p ai-learning-assistant -f compose.ecs.yml config --quiet
docker compose -p ai-learning-assistant -f compose.ecs.yml up -d --no-build
bash scripts/check-cloud-evidence.sh 120.26.28.223
```

Capture the actual externally opened `http://120.26.28.223:14242/ui/` with the
browser address bar. A loopback check cannot replace that evidence. Preserve
any failure in the log and diagnose it separately.

Before exposing Nginx, recreate the backend with its localhost-only binding:

```bash
unset AILA_BIND_IP
docker compose -p ai-learning-assistant -f compose.ecs.yml up -d --no-build
docker compose -p ai-learning-assistant -f compose.ecs.yml ps
curl -fsS http://127.0.0.1:14242/health
```

Confirm the published host address is now `127.0.0.1`, not `0.0.0.0` or `[::]`.
Do not use `docker compose down -v` or delete `data/` to switch images.

## 4. Prepare the reviewed Nginx site

This stage assumes the domain is ready for public service and the valid server
certificate already exists. A dedicated client CA certificate must be supplied
as `/etc/nginx/aila-client-ca.pem`; the authorized user needs a matching issued
client identity (certificate plus private key, normally packaged as a protected
`.p12`/`.pfx` bundle for browser import). Use a CA that issues only authorized
client identities, not a general public-web CA. Keep its private signing key
offline and outside the server/repository. No client identities have been issued
as part of this preparation.

Nginx's [client-certificate verification directives](https://nginx.org/en/docs/http/ngx_http_ssl_module.html#ssl_verify_client)
provide this independent access check. Certificate validity and issuance policy
still need review; the application's BNBU login remains a separate step.

If Nginx/Certbot tools are absent on Ubuntu, installation commands are:

```bash
sudo apt update
sudo apt install nginx certbot
```

Inspect existing sites first; do not remove `/etc/nginx/sites-enabled/default`
or overwrite another website simply to install this assignment. Review any
existing block for the same hostname and coordinate a single intended site.

```bash
sudo ls -l /etc/nginx/sites-available /etc/nginx/sites-enabled
export AILA_DOMAIN='YOUR_DOMAIN'
AILA_STAGE_DIR="$(mktemp -d)"
cp docs/deployment/nginx-https.conf.example "$AILA_STAGE_DIR/ai-agent.conf"
```

Edit the staged file in an editor, replacing all `YOUR_DOMAIN` occurrences with
the exact controlled hostname. Confirm the certificate paths match the actual
valid certificate, and that its SAN includes that hostname:

```bash
sudo openssl x509 -in "/etc/letsencrypt/live/$AILA_DOMAIN/fullchain.pem" \
  -noout -dates -ext subjectAltName
sudo test -r "/etc/letsencrypt/live/$AILA_DOMAIN/privkey.pem"
sudo test -r /etc/nginx/aila-client-ca.pem
sudo openssl x509 -in /etc/nginx/aila-client-ca.pem -noout -subject -dates
```

The server needs only the public client-CA certificate chain to verify users;
it does not need the client's private key or the CA's signing key. Provision the
authorized client identity privately and have its owner import it into their
browser/keychain and select it when the site asks. Importing a client identity
is different from bypassing an invalid **server** certificate warning. Do not
disable either verification or change `ssl_verify_client on` to `optional` merely
to make a failed test appear successful.

Prepare the public ACME challenge directory without exposing the application:

```bash
sudo install -d -m 0755 /var/www/letsencrypt/.well-known/acme-challenge
```

If no certificate has been supplied, stop here. Obtain one using an approved
validation setup; do not enable a configuration pointing to nonexistent keys
or bypass a browser certificate error. For example, Certbot's webroot mode
requires a reachable HTTP challenge directory already served for this domain:

```bash
# Only after that challenge-only HTTP site is configured and verified:
sudo certbot certonly --webroot -w /var/www/letsencrypt \
  --cert-name "$AILA_DOMAIN" -d "$AILA_DOMAIN"
```

Follow the certificate provider's interactive terms/account steps.
[Certbot's webroot guide](https://eff-certbot.readthedocs.io/en/stable/using.html#webroot)
explains the validation prerequisite. Do not expose the app itself over HTTP
to obtain the certificate.

## 5. Install only the new reviewed site; validate before reload

Proceed only after the valid server certificate, dedicated client CA, and
authorized browser identity are ready. This template has not passed `nginx -t`
on the target server; it intentionally references files that must be supplied.

Check the staged content and that no placeholders remain. The commands below
intentionally refuse to overwrite an existing `ai-agent` config or symlink.
If either path exists, compare and back it up before planning an explicit update;
do not work around these guards with forced copy/link commands.

```bash
grep -n 'YOUR_' "$AILA_STAGE_DIR/ai-agent.conf"
# The command above should print no matches after editing.
sudo test ! -e /etc/nginx/sites-available/ai-agent && \
  sudo install -m 0644 "$AILA_STAGE_DIR/ai-agent.conf" \
    /etc/nginx/sites-available/ai-agent
sudo test ! -e /etc/nginx/sites-enabled/ai-agent && \
  sudo ln -s /etc/nginx/sites-available/ai-agent \
    /etc/nginx/sites-enabled/ai-agent
sudo nginx -t && sudo systemctl reload nginx
```

The template serves only ACME validation files on HTTP and redirects other HTTP
requests to HTTPS. Client-certificate verification covers the whole HTTPS server,
including API routes, UI assets, and `/health`; the app's bearer header is passed
through. Generation streams use disabled proxy buffering and 360-second
read/send timeouts. See [Nginx proxy directives](https://nginx.org/en/docs/http/ngx_http_proxy_module.html).

## 6. Verify real HTTPS and access control, then record evidence

These ECS loopback tests keep normal server-certificate verification enabled.
Expect an HTTP redirect. The HTTPS request **without** a client certificate must
be refused (TLS failure or a non-success HTTP response), never show the app with
HTTP 200. A missing/invalid client certificate does not necessarily return 401.

```bash
curl --resolve "$AILA_DOMAIN:80:127.0.0.1" -I "http://$AILA_DOMAIN/ui/"
curl --resolve "$AILA_DOMAIN:443:127.0.0.1" -sS -o /dev/null \
  -w '%{http_code}\n' "https://$AILA_DOMAIN/ui/"
```

Only after local verification and domain/filing readiness, allow inbound TCP
80/443 in the cloud security group. Remove the public 14242 rule and retain SSH
restrictions. From the student's computer with an authorized PEM client identity,
an equivalent positive check is:

```bash
# On the student's computer; replace private file paths, never paste key contents.
export AILA_DOMAIN='YOUR_DOMAIN'
curl --cert '/PRIVATE/PATH/client.crt' --key '/PRIVATE/PATH/client.key' \
  -sS -o /dev/null -w '%{http_code}\n' "https://$AILA_DOMAIN/ui/"
```

Expect 200 only with a valid authorized identity. Recheck in the browser after
its owner imports/selects the client identity: display the app over the valid
HTTPS hostname, then complete the normal BNBU login and real artifact generation.
Capture the successful page with its address bar; also preserve the negative
access-check result. A private browser window may still use an identity installed
in the operating-system keychain, so it alone does not prove unauthenticated
rejection. Use the no-certificate curl check for that proof.

Check certificate renewal before treating deployment as complete:

```bash
sudo certbot renew --dry-run
systemctl list-timers --all | grep certbot
```

Ensure the installed renewal mechanism reloads Nginx after a successful renewal;
review its existing hook before adding another. Record the actual result and
remaining failures. This document and its example configuration are preparation,
not substitutes for the required screenshots, real ECS log, ACR digest, or HTTPS
URL evidence.
