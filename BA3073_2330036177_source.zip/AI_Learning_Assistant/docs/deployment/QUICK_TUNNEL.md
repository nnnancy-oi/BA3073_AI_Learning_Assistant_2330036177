# Optional free, temporary HTTPS demonstration

This is a separate alternative to the assignment's prescribed deployment. It
does not create a student-controlled DNS A record pointing to ECS and does not
issue a Certbot certificate on ECS. Do not mark all Task 3 criteria complete
from a tunnel screenshot. Check applicable hosting requirements separately.

Architecture: browser → Cloudflare managed HTTPS and email one-time PIN gate →
outbound encrypted cloudflared connection on ECS → loopback Nginx at
127.0.0.1:18080 → backend at 127.0.0.1:14242. The email gate is independent of
the application's teaching login. It uses a cookie and preserves the app's
Authorization bearer header.

Use the official cloudflared release and verify its published SHA256 before
installation. The examples require a version supporting `--allowed-mail`.
Prepare and syntax-check Nginx first. Replace the sample allowed email only
with an authorized address. Never expose the app using an unprotected quick
tunnel. No API key, application password, or database belongs in the service
unit or source package.

The official version used for feasibility testing is 2026.10.7. The Linux amd64
binary SHA256 published by Cloudflare is
`1f99fb518b83dec2ba8d870a7cc991d82a77e6196295a3d2754ba17ab9f91872`.

The Nginx and tunnel systemd examples are preparation until deployment evidence
confirms their running state. After the independent gate and authorized access
are verified, keep the backend on loopback and remove the temporary public
14242 security-group rule. Preserve Task 2's earlier direct-IP evidence.

Quick Tunnels are for development/testing, have no availability guarantee, and
the hostname changes after creating a new tunnel. A stopped process invalidates
its address. Cloudflare terminates HTTPS and processes traffic and access email
addresses. This route does not need a purchased domain or a Cloudflare account.
The service example deliberately does not auto-restart: a restart creates a new
hostname that must be recorded and re-verified. The main UI uses polling; the
provider's lack of SSE support still limits any direct SSE clients.

Validation must include a valid certificate without bypass flags, an anonymous
redirect to the email gate, successful authorized browser access with the full
address bar, backend loopback binding, and preservation of the app's bearer
authentication. A displayed gate alone does not prove authorized access.

Stop the demonstration with `systemctl disable --now ba3073-quick-tunnel`.
Remove only its Nginx configuration and reload Nginx after validating the result.
Do not erase application data or change credentials during rollback.

Primary references (checked 2 November 2026):

- https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/
- https://github.com/cloudflare/cloudflared/releases/tag/2026.10.7


## Latest verified update — 2026-11-02T22:37:06+08:00

official cloudflared 2026.10.7 checksum-verified and installed; Nginx configured at 127.0.0.1:18080; both services active. Temporary endpoint: https://style-mixing-van-advancement.trycloudflare.com/ui/
Anonymous request: HTTP 302 to email authentication, TLS certificate verification result 0. The student completed the email PIN, but JavaScript/CSS redirected to authentication and failed CORS checks. Full application UI and persistent authorized admission are NOT verified. Backend direct-IP access remains restricted to the authorized /32; it has not been closed because the replacement path is unverified.

No student-controlled DNS A record to ECS or Certbot certificate on ECS. No domain purchased. Temporary provider hostnames are not equivalent to the specified architecture and may stop/change. Do not describe this as a completed Task 3. See docs/deployment/QUICK_TUNNEL.md.

