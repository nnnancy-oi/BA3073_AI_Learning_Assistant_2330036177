# Assignment verification - 2 November 2026

## Passed checks

- Current-source local cached-runtime build, healthy localhost-only project, health JSON ok, UI HTTP 200 and actual Safari login page. Local log PASS at 17:32:38 +0800. Clean dependency build failed at Docker Hub authorization timeout; not claimed successful.
- Frontend 12 tests passed using Node.js. Backend 117 tests passed in 7.52s with mocked providers in an isolated disposable container using current read-only-mounted tests.
- Separate local arm64 and ECS amd64 images inspected. Actual local ACR push and ECS pull share digest `sha256:a93dc14f240116d4a95f6577689cf62d4560fbdd6147b05273f2a45324e4f266`.
- ECS replacement about 19:44 +0800: container 92a08e22a1cf healthy; loopback checks pass. Existing mounts/settings/accounts preserved; consistent private backup exists. Restore untested.
- TCP 14242 source corrected to current single IPv4 /32 after explicit user confirmation; fresh authorized Mac-to-ECS UI HTTP 200.
- `essay_html.py` source/local/ECS SHA256 matches `aaaaa483f136d78cc178028bfd07bb00a13f6d63fd3d18d8b5b6909ff8c55cc9`.
- Live service run 43c63132-df0c-4e5a-838b-d2ea8a180550 succeeded with qwen3.6-flash. Provider 66.252s, total 69.145s. Original generated HTML/PDF/manifest retained. Invoked through service core over SSH under existing account, not through browser interaction.
- Revised interim report: at most 20 A4 pages, all pages rendered and visually reviewed; actual historical cloud screenshots embedded. Final Task 3 evidence pending.
- ECS-check helper mocked default/override/no-backend/health-failure cases passed. Deployment helper shell syntax and mocked success/pull-failure/startup-failure-with-rollback passed.
- Prepared Nginx template passed isolated nginx -t with synthetic test certificates only. Not a real ECS/TLS/client-identity check.

## Failed or missing evidence

- ECS-origin self-request to public IP still HTTP 000 / curl 28, kept as FAIL. Authorized external and loopback checks succeed; root cause not established.
- Current local Safari and ECS Chrome address-bar captures are saved. Historical essay preview is separately identified; no screenshot proves HTTPS.
- No authorized domain/DNS, deployed Nginx, trusted HTTPS, independent proxy rejection/admission test, or Task 3 screenshots.
- Public GitHub repository contains the full current-source ZIP and separately committed revised essay prompt; public visibility was user-approved.

Application authentication/session behavior was not changed. Secrets and runtime data remain outside source submission. See docs/ASSIGNMENT_PROGRESS.md for provenance and limitations.


## Latest verified update — 2026-11-02T22:37:06+08:00

official cloudflared 2026.10.7 checksum-verified and installed; Nginx configured at 127.0.0.1:18080; both services active. Temporary endpoint: https://style-mixing-van-advancement.trycloudflare.com/ui/
Anonymous request: HTTP 302 to email authentication, TLS certificate verification result 0. The student completed the email PIN, but JavaScript/CSS redirected to authentication and failed CORS checks. Full application UI and persistent authorized admission are NOT verified. Backend direct-IP access remains restricted to the authorized /32; it has not been closed because the replacement path is unverified.

No student-controlled DNS A record to ECS or Certbot certificate on ECS. No domain purchased. Temporary provider hostnames are not equivalent to the specified architecture and may stop/change. Do not describe this as a completed Task 3. See docs/deployment/QUICK_TUNNEL.md.

