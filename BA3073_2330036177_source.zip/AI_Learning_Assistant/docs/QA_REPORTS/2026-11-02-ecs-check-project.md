# ECS helper Compose project selection

Date: 2 November 2026

## Problem and correction

The launchers and documented workflow start Compose with the project name
`ai-learning-assistant`. The older `scripts/check-ecs-docker.sh` omitted `-p`
when listing services, allowing the checkout directory name to select another
project and report a false failure even with the intended container running.

The helper now passes an explicit project and file:

- `AILA_COMPOSE_PROJECT`, default `ai-learning-assistant`.
- `AILA_COMPOSE_FILE`, default the project's `compose.yml`.

Other checks and output remain unchanged. Set the file override when checking
an ECS deployment created with `compose.ecs.yml`.

## Verification

- `bash -n scripts/check-ecs-docker.sh`: passed.
- Temporary mock Docker/curl checks: default project/file passed; explicit
  project/file override passed; absent backend returned 1; failed health
  request returned 1.
- The mock fixture was created in a temporary directory and removed after
  verification. It wrote no real deployment evidence into the source folder.

## Boundary

This helper confirms a Compose backend and health endpoint; it does not prove
external browser rendering, ACR transfer, model generation, or HTTPS/reverse-proxy
authentication. Use the separate cloud-evidence helper for the assignment's
container/public-IP log, and collect actual browser evidence separately.

No API contracts or application behavior changed.
