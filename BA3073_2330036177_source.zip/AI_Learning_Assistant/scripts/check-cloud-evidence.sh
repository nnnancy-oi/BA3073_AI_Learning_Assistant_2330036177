#!/usr/bin/env bash
# Run on ECS. Pass its public IPv4 address as the first argument.
set -uo pipefail
if [[ $# != 1 || ! $1 =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
  echo "Usage: bash scripts/check-cloud-evidence.sh ECS_PUBLIC_IPV4" >&2
  exit 2
fi
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec > >(tee "${ROOT_DIR}/ecs-docker-check.txt") 2>&1
failed=0
echo 'AI Learning Assistant ECS Web Interface Check'
date '+Time (local): %Y-%m-%dT%H:%M:%S%z'
date -u '+Time (UTC): %Y-%m-%dT%H:%M:%SZ'
echo "Machine: $(hostname)"
echo "Operating system: $(uname -sr)"
echo "CPU architecture: $(uname -m)"
echo "ECS login user: $(whoami)"
echo "Website URL: http://$1:14242/ui/"
docker --version || failed=1
docker ps -a --filter publish=14242 --format 'table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' || failed=1
for endpoint in http://127.0.0.1:14242/health http://127.0.0.1:14242/ui/ "http://$1:14242/ui/"; do
  echo "Checking: ${endpoint}"
  status=$(curl --noproxy '*' -sS --connect-timeout 5 --max-time 15 -o /dev/null -w '%{http_code}' "$endpoint")
  result=$?
  echo "HTTP status: ${status}; curl exit code: ${result}"
  if [[ $result == 0 && $status == 200 ]]; then
    echo 'Endpoint check: PASS'
  else
    echo 'Endpoint check: FAIL'
    failed=1
  fi
done
echo 'Browser access from your own computer must be checked separately.'
echo 'A failed ECS public-IP self-check does not establish its root cause.'
exit "$failed"
