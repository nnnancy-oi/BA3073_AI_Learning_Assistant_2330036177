#!/usr/bin/env bash
# Run on the existing ECS after docker login using a task-owned temporary config.
# Usage: bash scripts/deploy-acr-on-ecs.sh /tmp/yyh-acr-pull.XXXXXX
set -euo pipefail
umask 077

AILA_AUTH_DIR="${1:-}"
AILA_PROJECT_DIR="${AILA_ECS_PROJECT_DIR:-/root/ba3073/AI_Learning_Assistant}"
AILA_PROJECT='ai-learning-assistant'
AILA_DEPLOY_IMAGE="${AILA_DEPLOY_IMAGE:-crpi-qworj2939ff08rp2.cn-hangzhou.personal.cr.aliyuncs.com/yyh-ba3073-2026/ai-learning-assistant@sha256:a93dc14f240116d4a95f6577689cf62d4560fbdd6147b05273f2a45324e4f266}"
AILA_PUBLIC_IP='120.26.28.223'
AILA_STOPPED=0
AILA_DEPLOYED=0

case "${AILA_AUTH_DIR}" in
  /tmp/yyh-acr-pull.*) ;;
  *) echo 'Pass the temporary /tmp/yyh-acr-pull.* Docker config directory.' >&2; exit 2 ;;
esac
[[ -f "${AILA_AUTH_DIR}/config.json" ]] || { echo 'Registry login is required first.' >&2; exit 2; }
[[ $(uname -m) == x86_64 ]] || { echo 'This deployment requires an x86_64 ECS.' >&2; exit 2; }
cd "${AILA_PROJECT_DIR}"
[[ -f compose.yml && -d data && -d workspace ]] || { echo 'Existing project/data directories not found.' >&2; exit 2; }
exec > >(tee ecs-acr-deploy-check.txt) 2>&1

cleanup() {
  local exit_code=$?
  # Remove only this task's temporary login file/directory, never ~/.docker.
  rm -f -- "${AILA_AUTH_DIR}/config.json"
  rmdir -- "${AILA_AUTH_DIR}" 2>/dev/null || true
  if [[ ${exit_code} != 0 && ${AILA_STOPPED} == 1 && ${AILA_DEPLOYED} == 0 ]]; then
    echo 'Deployment failed; attempting to resume the previous Compose image.'
    docker compose -p "${AILA_PROJECT}" -f compose.yml up -d --no-build --pull never || true
    echo 'Persistent-state backup was retained. No data was automatically restored or deleted.'
  fi
}
trap cleanup EXIT

echo 'BA3073 ECS deployment from ACR'
date '+Time (local): %Y-%m-%dT%H:%M:%S%z'
echo "Pinned image: ${AILA_DEPLOY_IMAGE}"
docker --version
docker compose version
docker --config "${AILA_AUTH_DIR}" pull "${AILA_DEPLOY_IMAGE}"
AILA_PLATFORM="$(docker image inspect "${AILA_DEPLOY_IMAGE}" --format '{{.Os}}/{{.Architecture}}')"
[[ "${AILA_PLATFORM}" == linux/amd64 ]] || { echo 'Unexpected image architecture.'; exit 1; }
docker image inspect "${AILA_DEPLOY_IMAGE}" --format 'Pulled platform: {{.Os}}/{{.Architecture}}; repository digests: {{json .RepoDigests}}'

# Back up state consistently while the sole backend is stopped. Keep backups
# outside the submitted source. Existing ports/environment/bind mounts remain
# in the original compose.yml and are preserved by this image-only override.
AILA_BACKUP_DIR="$(mktemp -d "$(dirname "${AILA_PROJECT_DIR}")/yyh-pre-acr.XXXXXX")"
cp -p compose.yml "${AILA_BACKUP_DIR}/compose.previous.yml"
if [[ -f ecs-docker-check.txt ]]; then cp -p ecs-docker-check.txt "${AILA_BACKUP_DIR}/ecs-docker-check.previous.txt"; fi
if [[ -f compose.acr.override.yml ]]; then cp -p compose.acr.override.yml "${AILA_BACKUP_DIR}/compose.acr.override.previous.yml"; fi
echo "Private backup directory: ${AILA_BACKUP_DIR}"
AILA_STOPPED=1
docker compose -p "${AILA_PROJECT}" -f compose.yml stop backend
tar -czf "${AILA_BACKUP_DIR}/persistent-state.tar.gz" data workspace

cat > compose.acr.override.yml <<'YAML'
services:
  backend:
    image: REPLACE_WITH_PINNED_IMAGE
    restart: unless-stopped
YAML
python3 - "${AILA_DEPLOY_IMAGE}" <<'PYIMAGE'
from pathlib import Path
import sys
path = Path('compose.acr.override.yml')
path.write_text(path.read_text().replace('REPLACE_WITH_PINNED_IMAGE', sys.argv[1]))
PYIMAGE
export AILA_DEPLOY_IMAGE
docker compose -p "${AILA_PROJECT}" -f compose.yml -f compose.acr.override.yml config --quiet
docker compose -p "${AILA_PROJECT}" -f compose.yml -f compose.acr.override.yml up -d --no-build --pull never --wait --wait-timeout 120
curl --noproxy '*' -fsS --connect-timeout 5 --max-time 15 http://127.0.0.1:14242/health
echo
AILA_UI_STATUS="$(curl --noproxy '*' -sS --connect-timeout 5 --max-time 15 -o /dev/null -w '%{http_code}' http://127.0.0.1:14242/ui/)"
[[ "${AILA_UI_STATUS}" == 200 ]] || { echo "UI check failed: ${AILA_UI_STATUS}"; exit 1; }
AILA_DEPLOYED=1

{
  echo 'AI Learning Assistant ECS Web Interface Check'
  date '+Time (local): %Y-%m-%dT%H:%M:%S%z'
  date -u '+Time (UTC): %Y-%m-%dT%H:%M:%SZ'
  echo "Machine: $(hostname)"
  echo "Operating system: $(uname -sr)"
  echo "CPU architecture: $(uname -m)"
  echo "ECS login user: $(whoami)"
  echo "Website URL: http://${AILA_PUBLIC_IP}:14242/ui/"
  docker --version
  docker ps -a --filter publish=14242 --format 'table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
  echo "Local UI status: ${AILA_UI_STATUS}"
  echo 'Local health response:'
  curl --noproxy '*' -fsS --connect-timeout 5 --max-time 15 http://127.0.0.1:14242/health
  echo
  echo 'Website URL check from ECS:'
  set +e
  AILA_STATUS="$(curl --noproxy '*' -sS --connect-timeout 5 --max-time 15 -o /dev/null -w '%{http_code}' "http://${AILA_PUBLIC_IP}:14242/ui/")"
  AILA_CURL_RESULT=$?
  set -e
  echo "HTTP status: ${AILA_STATUS}; curl exit code: ${AILA_CURL_RESULT}"
  if [[ ${AILA_CURL_RESULT} == 0 && "${AILA_STATUS}" == 200 ]]; then
    echo 'Website URL check: PASS'
  else
    echo 'Website URL check: FAIL - external browser access must be checked separately.'
  fi
} | tee ecs-docker-check.txt
echo 'ACR pull, container startup, loopback health and UI checks: PASS'
echo 'No domain/HTTPS/security-group change was made by this script.'
